import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom/client';

function App() {
  const [products, setProducts] = useState([]);

  useEffect(() => {
    fetch('http://localhost:3001/api/products')
      .then(res => res.json())
      .then(data => setProducts(data))
      .catch(err => console.error('Erro ao buscar produtos:', err));
  }, []);

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Coreia em Casa 🍜</h1>
      {products.length === 0 ? (
        <p>Carregando produtos...</p>
      ) : (
        <ul>
          {products.map(prod => (
            <li key={prod.id}>
              {prod.name} – R$ {prod.price.toFixed(2)}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
