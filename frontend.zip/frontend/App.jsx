import React, { useEffect, useState } from 'react';
import ReactDOM from 'react-dom/client';

function App() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('https://coreia-em-casa-backend.onrender.com/api/products')  // Alterado para o backend online
      .then(res => res.json())
      .then(data => {
        console.log("Produtos recebidos:", data);  // Veja no console se os produtos são retornados
        setProducts(data);
        setLoading(false);
      })
      .catch(err => {
        console.error('Erro ao buscar produtos:', err);
        setLoading(false);
      });
  }, []);

  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial' }}>
      <h1>Coreia em Casa 🍜</h1>
      {loading ? (
        <p>Carregando produtos...</p>
      ) : (
        <ul>
          {products.length > 0 ? (
            products.map(prod => (
              <li key={prod.id}>
                {prod.name} – R$ {prod.price.toFixed(2)}
              </li>
            ))
          ) : (
            <p>Não há produtos disponíveis.</p>
          )}
        </ul>
      )}
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
