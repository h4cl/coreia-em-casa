/coreia-em-casa
  /backend
    server.js
    package.json
    Procfile
    ...
  /frontend
    ...
