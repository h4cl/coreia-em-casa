const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

app.get('/api/products', (req, res) => {
  res.json([
    { id: 1, name: 'Topokki Pocket', price: 18.00 },
    { id: 2, name: 'Topokki Raiz', price: 22.00 },
    { id: 3, name: 'Topokki Oppa', price: 25.00 },
    { id: 4, name: 'Topokki Dorama', price: 29.00 },
    { id: 5, name: 'Morangô', price: 12.00 }
  ]);
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`✅ Servidor rodando em http://localhost:${PORT}`);
});
